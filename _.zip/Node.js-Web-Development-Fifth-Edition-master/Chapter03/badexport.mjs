{
    export const meaning = 42;
}