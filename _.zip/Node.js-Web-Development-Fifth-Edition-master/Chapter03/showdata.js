const data = require('./data.json');

console.log(data);