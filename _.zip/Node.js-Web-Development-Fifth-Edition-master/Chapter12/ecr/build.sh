( cd ../notes && npm run docker-build )
( cd ../users && npm run docker-build )
