aws ecr describe-repositories
