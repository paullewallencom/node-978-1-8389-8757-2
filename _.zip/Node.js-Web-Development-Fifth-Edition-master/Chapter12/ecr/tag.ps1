docker tag svc-notes:latest %AWS_USER%.dkr.ecr.%AWS_REGION%.amazonaws.com/svc-notes:latest
docker tag svc-userauth:latest %AWS_USER%.dkr.ecr.%AWS_REGION%.amazonaws.com/svc-userauth:latest

